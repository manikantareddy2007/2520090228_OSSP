#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#define WORKER_COUNT 3
#define TASK_COUNT 10
#define QUEUE_CAPACITY 5

typedef enum {
    TASK_QUEUED,
    TASK_RUNNING,
    TASK_COMPLETED,
    TASK_FAILED
} TaskStatus;

typedef struct {
    int id;
    int work_ms;
    int should_fail;
    TaskStatus status;
    long long start_ms;
    long long end_ms;
    char result[128];
    char error[128];
} Task;

typedef struct {
    Task *items[QUEUE_CAPACITY];
    int head;
    int tail;
    int count;
    int stopping;
    pthread_mutex_t mutex;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;
} TaskQueue;

static TaskQueue queue;
static Task tasks[TASK_COUNT];
static pthread_mutex_t stats_mutex = PTHREAD_MUTEX_INITIALIZER;
static int completed_count = 0;
static int failed_count = 0;

static long long now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
}

static void sleep_ms(int ms) {
    struct timespec req;
    req.tv_sec = ms / 1000;
    req.tv_nsec = (long)(ms % 1000) * 1000000L;
    while (nanosleep(&req, &req) == -1 && errno == EINTR) {
        /* Resume sleeping if interrupted by a signal. */
    }
}

static const char *status_name(TaskStatus status) {
    switch (status) {
        case TASK_QUEUED: return "QUEUED";
        case TASK_RUNNING: return "RUNNING";
        case TASK_COMPLETED: return "COMPLETED";
        case TASK_FAILED: return "FAILED";
        default: return "UNKNOWN";
    }
}

static int queue_init(TaskQueue *q) {
    memset(q, 0, sizeof(*q));
    if (pthread_mutex_init(&q->mutex, NULL) != 0) return -1;
    if (pthread_cond_init(&q->not_empty, NULL) != 0) return -1;
    if (pthread_cond_init(&q->not_full, NULL) != 0) return -1;
    return 0;
}

/* Blocks when the bounded queue is full. */
static int queue_push(TaskQueue *q, Task *task) {
    pthread_mutex_lock(&q->mutex);
    while (q->count == QUEUE_CAPACITY && !q->stopping) {
        pthread_cond_wait(&q->not_full, &q->mutex);
    }
    if (q->stopping) {
        pthread_mutex_unlock(&q->mutex);
        return -1;
    }
    q->items[q->tail] = task;
    q->tail = (q->tail + 1) % QUEUE_CAPACITY;
    q->count++;
    printf("[SUBMIT] Task %02d added to queue (queue size: %d/%d)\n",
           task->id, q->count, QUEUE_CAPACITY);
    pthread_cond_signal(&q->not_empty);
    pthread_mutex_unlock(&q->mutex);
    return 0;
}

/* Returns NULL only when shutdown is requested and the queue is empty. */
static Task *queue_pop(TaskQueue *q) {
    pthread_mutex_lock(&q->mutex);
    while (q->count == 0 && !q->stopping) {
        pthread_cond_wait(&q->not_empty, &q->mutex);
    }
    if (q->count == 0 && q->stopping) {
        pthread_mutex_unlock(&q->mutex);
        return NULL;
    }
    Task *task = q->items[q->head];
    q->head = (q->head + 1) % QUEUE_CAPACITY;
    q->count--;
    pthread_cond_signal(&q->not_full);
    pthread_mutex_unlock(&q->mutex);
    return task;
}

static void *worker_main(void *arg) {
    long worker_id = (long)arg;
    char worker_name[32];
    snprintf(worker_name, sizeof(worker_name), "Worker-%ld", worker_id);

    for (;;) {
        Task *task = queue_pop(&queue);
        if (task == NULL) break;

        task->status = TASK_RUNNING;
        task->start_ms = now_ms();
        printf("[START]  Task %02d picked by %s (%d ms)\n",
               task->id, worker_name, task->work_ms);

        sleep_ms(task->work_ms);

        if (task->should_fail) {
            task->status = TASK_FAILED;
            snprintf(task->error, sizeof(task->error),
                     "Simulated task error");
            pthread_mutex_lock(&stats_mutex);
            failed_count++;
            pthread_mutex_unlock(&stats_mutex);
            printf("[FAIL]   Task %02d on %s: %s\n",
                   task->id, worker_name, task->error);
        } else {
            task->status = TASK_COMPLETED;
            snprintf(task->result, sizeof(task->result),
                     "Processed successfully by %s", worker_name);
            pthread_mutex_lock(&stats_mutex);
            completed_count++;
            pthread_mutex_unlock(&stats_mutex);
            printf("[DONE]   Task %02d on %s\n", task->id, worker_name);
        }

        task->end_ms = now_ms();
    }
    printf("[EXIT]   %s stopped\n", worker_name);
    return NULL;
}

static void queue_shutdown(TaskQueue *q) {
    pthread_mutex_lock(&q->mutex);
    q->stopping = 1;
    pthread_cond_broadcast(&q->not_empty);
    pthread_cond_broadcast(&q->not_full);
    pthread_mutex_unlock(&q->mutex);
}

static void run_sequential_baseline(void) {
    long long start = now_ms();
    for (int i = 0; i < TASK_COUNT; i++) {
        sleep_ms(tasks[i].work_ms);
    }
    long long end = now_ms();
    printf("Sequential baseline (same simulated work): %lld ms\n", end - start);
}

int main(void) {
    pthread_t workers[WORKER_COUNT];
    int work_times[TASK_COUNT] = {450, 650, 500, 700, 550, 400, 600, 350, 500, 450};

    printf("====================================================\n");
    printf("       THREAD POOL BASED TASK PROCESSING SYSTEM\n");
    printf("             Operating Systems Project (C)\n");
    printf("====================================================\n");
    printf("Workers: %d | Tasks: %d | Queue capacity: %d\n\n",
           WORKER_COUNT, TASK_COUNT, QUEUE_CAPACITY);

    if (queue_init(&queue) != 0) {
        fprintf(stderr, "Failed to initialize task queue synchronization.\n");
        return EXIT_FAILURE;
    }

    for (int i = 0; i < TASK_COUNT; i++) {
        tasks[i].id = i + 1;
        tasks[i].work_ms = work_times[i];
        tasks[i].should_fail = (i == 4); /* Task 5 intentionally fails. */
        tasks[i].status = TASK_QUEUED;
        tasks[i].start_ms = 0;
        tasks[i].end_ms = 0;
        tasks[i].result[0] = '\0';
        tasks[i].error[0] = '\0';
    }

    long long overall_start = now_ms();

    for (long i = 1; i <= WORKER_COUNT; i++) {
        int rc = pthread_create(&workers[i - 1], NULL, worker_main, (void *)i);
        if (rc != 0) {
            fprintf(stderr, "pthread_create failed: %s\n", strerror(rc));
            queue_shutdown(&queue);
            for (long j = 1; j < i; j++) pthread_join(workers[j - 1], NULL);
            return EXIT_FAILURE;
        }
    }

    for (int i = 0; i < TASK_COUNT; i++) {
        if (queue_push(&queue, &tasks[i]) != 0) {
            fprintf(stderr, "Task submission rejected during shutdown.\n");
            break;
        }
    }

    printf("\n[INFO] All tasks submitted. Waiting for workers...\n\n");
    queue_shutdown(&queue);

    for (int i = 0; i < WORKER_COUNT; i++) {
        pthread_join(workers[i], NULL);
    }

    long long overall_end = now_ms();
    long long concurrent_ms = overall_end - overall_start;

    printf("\n==================== TASK REPORT ====================\n");
    for (int i = 0; i < TASK_COUNT; i++) {
        long long duration = (tasks[i].start_ms == 0) ? 0 :
            tasks[i].end_ms - tasks[i].start_ms;
        printf("Task %02d | %-9s | %4lld ms\n",
               tasks[i].id, status_name(tasks[i].status), duration);
        if (tasks[i].status == TASK_FAILED) {
            printf("         Error: %s\n", tasks[i].error);
        }
    }

    printf("\n================ PERFORMANCE SUMMARY ================\n");
    printf("Tasks submitted       : %d\n", TASK_COUNT);
    printf("Completed             : %d\n", completed_count);
    printf("Failed                : %d\n", failed_count);
    printf("Workers               : %d\n", WORKER_COUNT);
    printf("Queue capacity        : %d\n", QUEUE_CAPACITY);
    printf("Concurrent elapsed    : %lld ms\n", concurrent_ms);
    double throughput = concurrent_ms > 0
        ? (double)TASK_COUNT * 1000.0 / (double)concurrent_ms : 0.0;
    printf("Submission throughput : %.2f tasks/second\n", throughput);
    printf("Note: timing varies by machine and scheduling.\n");

    printf("\n================ SEQUENTIAL COMPARISON ===============\n");
    run_sequential_baseline();
    printf("======================================================\n");

    pthread_cond_destroy(&queue.not_empty);
    pthread_cond_destroy(&queue.not_full);
    pthread_mutex_destroy(&queue.mutex);
    pthread_mutex_destroy(&stats_mutex);
    return EXIT_SUCCESS;
}
