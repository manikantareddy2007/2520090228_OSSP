# Thread Pool Based Task Processing System (C / POSIX Threads)

## Overview
This Operating Systems mini-project implements a custom thread pool in C using POSIX threads (`pthreads`). A fixed set of worker threads consumes tasks from a bounded FIFO queue. The queue uses a mutex and condition variables for safe coordination.

## Features
- Fixed worker pool (3 workers in the demo)
- Bounded FIFO task queue (capacity 5)
- Mutex-protected queue operations
- Condition variables for `not_empty` and `not_full`
- Task lifecycle states: QUEUED, RUNNING, COMPLETED, FAILED
- Error demonstration: Task 5 intentionally fails; other tasks continue
- Graceful shutdown: workers finish queued tasks before exiting
- Timing, throughput, and sequential baseline comparison

## Requirements
- Ubuntu Linux (or another POSIX-compatible system)
- GCC compiler
- POSIX threads library (provided by the standard Linux development toolchain)

## Install tools on Ubuntu
```bash
sudo apt update
sudo apt install build-essential
```

## Compile
From the project directory:
```bash
gcc -Wall -Wextra -Wpedantic -std=c11 -pthread src/thread_pool.c -o thread_pool
```

## Run
```bash
./thread_pool
```

## Expected behavior
The program submits 10 tasks to a queue. Three workers process tasks concurrently. Task 5 is deliberately marked as a failed task to demonstrate error handling. The exact log order and timing depend on your computer and thread scheduling.

## Operating Systems concepts demonstrated
1. **Multithreading:** multiple worker threads execute tasks.
2. **Scheduling:** workers take the oldest available task from the FIFO queue.
3. **Mutual exclusion:** a mutex protects queue indices, queue count, and shutdown state.
4. **Condition variables:** idle workers sleep while the queue is empty; producers wait while it is full.
5. **Synchronization:** signals and broadcasts coordinate producers, workers, and shutdown.
6. **Resource management:** a fixed worker count bounds the number of concurrent workers.
7. **Graceful termination:** queued work is completed before workers exit.
8. **Performance measurement:** monotonic-clock timings and throughput are printed.

## Important notes
- The workload uses sleeps to simulate tasks, so the benchmark demonstrates overlapping waiting/work time, not CPU-bound speedup.
- The queue is bounded, but the number of tasks in this demonstration is fixed in the source.
- This is an educational prototype, not a production scheduler.
